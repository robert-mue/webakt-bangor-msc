(function ($) {

  /***********************************************************
   *         diagram widget
   ***********************************************************
   */
    $.widget('akt.diagram', {
        meta:{
            short_description: 'Displays causal and link relationships',
            long_description: 'Displays causal and link relationships',
            author: 'Robert Muetzelfeldt',
            last_modified: 'March 2021',
            visible: true,
            options: {
            }
        },

        options: {
            kb:null,
            show_titlebar:true
        },

        evaluate: function(kb) {
            var results = evaluate(kb);
            display(this, results);
            return results;
        },

        widgetEventPrefix: 'diagram:',

        _create: function () {
            console.debug('\n========================================\nStarting diagram...');
            console.debug(this.element);
            var self = this;
            this.element.addClass('diagram-1');

            var kb = self.options.kb;
            var results = evaluate(kb);
            display(self, results);

            this._setOptions({
            });
        },

        _destroy: function () {
            this.element.removeClass('diagram-1');
            this.element.empty();
            this._super();
        },
        _setOption: function (key, value) {
            var self = this;
            var prev = this.options[key];
            var fnMap = {
            };

            // base
            this._super(key, value);

            if (key in fnMap) {
                fnMap[key]();

                // Fire event
                this._triggerOptionChanged(key, prev, value);
            }
        },

        _triggerOptionChanged: function (optionKey, previousValue, currentValue) {
            this._trigger('setOption', {type: 'setOption'}, {
                option: optionKey,
                previous: previousValue,
                current: currentValue
            });
        }
    });

    function evaluate(kb) {
        return null;
    }


    function display(widget, results) {
        console.debug('diagram: display');
        var instance = "something_unique";  // .... the widget's UUID
        var kb = widget.options.kb;

        if (widget.options.show_titlebar) {
            var widgetTitlebar = $('<div class="titlebar">diagram<input type="button" value="X" class="dialog_close_button"/></div>');  
            $(widget.element).append(widgetTitlebar);
            $('.dialog_close_button').css({background:'yellow'});
            $('.dialog_close_button').on('click', function () {
                var id = $(this).parent().parent()[0].id;
                $('#'+id).css({display:"none"});
            });
        }
        var widgetContent = $('<div class="content" style="padding:10px;padding-bottom:0px;top:0px;width:400px;height:400px;"></div>');
        $(widgetContent).resizable();
        $(widget.element).append(widgetContent);
       
        var topDiv = $('<div id="'+instance+'_top_div" style="width:100%; background:pink;"></div>');
        $(widgetContent).append(topDiv);
        $(topDiv).append('<div style="float:left;">Diagram 106</div>');
        $(topDiv).append('<option style="float:left;"value="all">all</option>');
        $(topDiv).append('<option style="float:left;"value="causal">causal</option>');
        $(topDiv).append('<option style="float:left;"value="link">link</option>');
        $(topDiv).append('<label for="'+instance+'_copy_to_clipboard">Copy to Clipboard</label>'+
            '<input type="button" id="'+instance+'_copy_to_clipboard" name="copy_to_clipboard">');
        $(topDiv).append('<label for="'+instance+'_menu">Menu</label>'+
            '<input type="button" id="'+instance+'_menu" name="menu">');


        var leftDiv = $('<div id="'+instance+'_left_div" style="float:left; width:100px; height:300px;"></div>');
        $(widgetContent).append(leftDiv);
        $(leftDiv).append(
        '<fieldset style="position:absolute; top:40px;left:10px;">'+
            '<legend>Add node</legend>'+
            '<input type="button" id="'+instance+'_add_object" name="add_object" value="Object" style="width:60px;"><br>'+
            '<input type="button" id="'+instance+'_add_attribute" name="add_attribute" value="Attribute" style="width:60px;"><br>'+
            '<input type="button" id="'+instance+'_add_process" name="add_process" value="Process" style="width:60px;"><br>'+
            '<input type="button" id="'+instance+'_add_action" name="add_action" value="Action" style="width:60px;"><br>'+
         '</fieldset><br><br>');
        $(leftDiv).append(
        '<fieldset style="position:absolute; top:150px;left:10px;">'+
            '<legend>Add</legend>'+
            '<input type="button" id="'+instance+'_add_link" name="link" value="Link"><br>'+
         '</fieldset><br><br>');
        $(leftDiv).append(
        '<fieldset style="position:absolute; top:200px;left:10px;">'+
            '<legend>Delete</legend>'+
            '<input type="button" id="'+instance+'_delete_node_or_link" name="node_or_link" value="Node/Link"><br>'+
         '</fieldset><br><br>');
        $(leftDiv).append(
        '<fieldset style="position:absolute; top:250px;left:10px;">'+
            '<legend>Hide</legend>'+
            '<input type="button" id="'+instance+'_hide_node_or_link" name="node_or_link" value="Node/Link"><br>'+
         '</fieldset><br><br>');
        $(leftDiv).append(
        '<fieldset style="position:absolute; top:300px;left:10px;">'+
            '<legend>Show/Hide</legend>'+
            '<input type="button" id="'+instance+'_show_hide_label" name="show_hide_label" value="Label"><br>'+
         '</fieldset>');


        var diagramDiv = $('<div id="'+instance+'_diagram_div" style="float:left; width:300px; height:300px;background:yellow;"></div>');
        $(widgetContent).append(diagramDiv);


        var rightDiv = $('<div id="'+instance+'_right_div" style="float:left; width:100px; background:red;"></div>');
        $(widgetContent).append(rightDiv);
        $(rightDiv).append(
            '<label for="'+instance+'_zoom_in">Label</label>'+
            '<input type="button" id="'+instance+'_zoom_in" name="zoom_in">');
        $(rightDiv).append(
            '<label for="'+instance+'_zoom_out">Label</label>'+
            '<input type="button" id="'+instance+'_zoom_out" name="zoom_out">');
        $(rightDiv).append(
            '<label for="'+instance+'_centre_zoom">Label</label>'+
            '<input type="button" id="'+instance+'_centre_zoom" name="centre_zoom">');
        $(rightDiv).append(
        '<fieldset>'+
            '<legend>Label Mode</legend>'+
            '<label for="'+instance+'_label_mode_left">&lt;</label>'+
            '<input type="button" id="'+instance+'_label_mode_left" name="label_mode_left">'+
            '<label for="'+instance+'_label_mode_right">&gt;</label>'+
            '<input type="button" id="'+instance+'_label_mode_right" name="label_mode_right">'+
            '<label for="'+instance+'_label_mode_auto">Auto</label>'+
            '<input type="button" id="'+instance+'_label_mode_auto" name="label_mode_auto">'+
         '</fieldset>');
        $(rightDiv).append(
            '<label for="'+instance+'_refresh">Label</label>'+
            '<input type="button" id="'+instance+'_refresh" name="refresh">');
        $(rightDiv).append(
            '<label for="'+instance+'_show_paths">Label</label>'+
            '<input type="button" id="'+instance+'_show_paths" name="show_paths">');
        $(rightDiv).append(
            '<label for="'+instance+'_print_window">Label</label>'+
            '<input type="button" id="'+instance+'_print_window" name="zprint_window">');
        $(rightDiv).append(
            '<label for="'+instance+'_statements">Label</label>'+
            '<input type="button" id="'+instance+'_statements" name="statements">');
        $(rightDiv).append(
        '<fieldset>'+
            '<legend>Explore</legend>'+
            '<label for="'+instance+'_navigate">Navigate</label>'+
            '<input type="button" id="'+instance+'_navigate" name="navigate">'+
            '<label for="'+instance+'_sources">Sources</label>'+
            '<input type="button" id="'+instance+'_sources" name="sources">'+
            '<label for="'+instance+'_causes">Causes</label>'+
            '<input type="button" id="'+instance+'_causes" name="causes">'+
            '<label for="'+instance+'_effects">Effects</label>'+
            '<input type="button" id="'+instance+'_effects" name="effects">'+
            '<label for="'+instance+'_undo">Undo</label>'+
            '<input type="button" id="'+instance+'_undo" name="undo">'+
         '</fieldset>');
        $(rightDiv).append(
        '<fieldset>'+
            '<legend>Select Diagram</legend>'+
            '<label for="'+instance+'_select_diagram_left">&lt;</label>'+
            '<input type="button" id="'+instance+'_select_diagram_left" name="select_diagram_left">'+
            '<label for="'+instance+'_select_diagram_right">&gt;</label>'+
            '<input type="button" id="'+instance+'_select_diagram_right" name="select_diagram_right">'+
         '</fieldset>');
    }

})(jQuery);
